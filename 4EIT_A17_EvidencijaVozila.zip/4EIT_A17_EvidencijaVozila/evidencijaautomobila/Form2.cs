﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace evidencijaautomobila
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-TOF6O3H\SQLEXPRESS;Initial Catalog=4EIT_A17_EvidencijaVozila;Integrated Security=True");


        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void Form2_Load(object sender, EventArgs e)
        {
            PuniComboKategorija();
        }

        private void PuniComboKategorija()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboModel", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Naziv";

            Kon.Close();
        }

        private void PuniGridChart()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Model", SqlDbType.VarChar).Value = comboBox1.Text.ToString();
            

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            dataGridView1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "GodinaProizvodnje";
            chart1.Series["Series1"].YValueMembers = "ProsCena";
            chart1.Titles.Add("PRIMER CHART");

            Kon.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PuniGridChart();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

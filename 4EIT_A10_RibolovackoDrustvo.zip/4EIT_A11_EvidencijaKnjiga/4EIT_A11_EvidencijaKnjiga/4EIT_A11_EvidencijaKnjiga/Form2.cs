﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A11_EvidencijaKnjiga
{
    public partial class Form2 : Form
    {
        SqlConnection Kon = new SqlConnection("Data Source=DESKTOP-TOF6O3H\\SQLEXPRESS;Initial Catalog=4EIT_A11_EvidencijaKnjiga;Integrated Security=True");
        public Form2()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            PuniCheckedListBox();
        }

        private void PuniCheckedListBox()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniCheckListBox", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();

            sda.Fill(dt);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                checkedListBox1.Items.Add(dt.Rows[i]["Autor"].ToString());
            }

            Kon.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PuniChart();
        }

        private void PuniChart()
        {
            if(checkedListBox1.CheckedItems.Count != 3)
            {
                MessageBox.Show("Odaberite samo 3 polja", "Greska", MessageBoxButtons.OK);
            }
            else
            {
                Kon.Open();

                SqlCommand cmd = new SqlCommand("PuniChart", Kon);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Autor1", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[0].ToString();
                cmd.Parameters.AddWithValue("@Autor2", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[1].ToString();
                cmd.Parameters.AddWithValue("@Autor3", SqlDbType.NVarChar).Value = checkedListBox1.CheckedItems[2].ToString();

                DataTable dt = new DataTable();
                dt.Load(cmd.ExecuteReader());

                chart1.DataSource = dt;

                chart1.Series["Autori"].XValueMember = "Autor";
                chart1.Series["Autori"].YValueMembers = "BrKnjiga";
                chart1.Titles.Add("Broj knjiga po autoru");

                Kon.Close();
            }
        }
    }
}

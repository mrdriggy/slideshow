﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A11_EvidencijaKnjiga
{
    public partial class Form1 : Form
    {

        SqlConnection Kon = new SqlConnection("Data Source=DESKTOP-TOF6O3H\\SQLEXPRESS;Initial Catalog=4EIT_A11_EvidencijaKnjiga;Integrated Security=True");

        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Form2 forma = new Form2();
            forma.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            AktivirajKontrole();
            PuniListView();
        }

        private void PuniListView()
        {
            listView1.Items.Clear();
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListView", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            IDataReader dr = cmd.ExecuteReader();

            while(dr.Read())
            {
                ListViewItem item = new ListViewItem(dr[0].ToString());
                item.SubItems.Add(dr[1].ToString());
                item.SubItems.Add(dr[2].ToString());
                item.SubItems.Add(dr[3].ToString());
                listView1.Items.Add(item);
            }

            Kon.Close();
        }

        private void AktivirajKontrole()
        {
            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = true;

            textBox2.Enabled = true;
            textBox3.Enabled = true;
            dateTimePicker1.Enabled = true;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void DeaktivirajKontrole()
        {
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = false;

            textBox2.Enabled = false;
            textBox3.Enabled = false;
            dateTimePicker1.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeaktivirajKontrole();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AktivirajKontrole();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListViewNaKontrole();
        }

        private void ListViewNaKontrole()
        {
            foreach(ListViewItem item in listView1.SelectedItems)
            {
                textBox1.Text = item.SubItems[0].Text.ToString();
                textBox2.Text = item.SubItems[1].Text.ToString();
                textBox3.Text = item.SubItems[2].Text.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(item.SubItems[3].Text);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpisPodataka();
        }

        private void UpisPodataka()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("InsertAutor", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ImeAutora", SqlDbType.NVarChar).Value = textBox2.Text.ToString();
            cmd.Parameters.AddWithValue("@PrezimeAutora", SqlDbType.NVarChar).Value = textBox3.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumRodjena", SqlDbType.Date).Value = dateTimePicker1.Value;

            cmd.ExecuteNonQuery();

            Kon.Close();

            PuniListView();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace evidencijaautomobila
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-TOF6O3H\SQLEXPRESS;Initial Catalog=4EIT_A17_EvidencijaVozila;Integrated Security=True");
    

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void PuniListBoxView()
        {
            listView1.Items.Clear();

            kom.Connection = Kon;
            kom.CommandText = "EXEC PuniListBoxView";
            Kon.Open();
            dr = kom.ExecuteReader();

            while (dr.Read())
            {

                ListViewItem red = new ListViewItem(dr[0].ToString());
                for (int i = 1; i < 8; i++) /* i IDE DO KOLIKO POLJA VRACA PROCEDURA*/
                    red.SubItems.Add(dr[i].ToString());
                listView1.Items.Add(red);
            }
            Kon.Close();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListBoxView();
            button2.Enabled = false;
            button2.Visible = false;
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }

        private void SaListViewNaKontrole()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                id = Convert.ToInt32(item.SubItems[0].Text);

                txtSifra.Text = id.ToString();
                txtRegistracija.Text = item.SubItems[1].Text;
                txtGodinaP.Text = item.SubItems[2].Text;
                txtPredjenaKM.Text = item.SubItems[3].Text;
                txtCena.Text = item.SubItems[7].Text;
                cmbModel.Text = item.SubItems[4].Text;
                cmbBoja.Text = item.SubItems[5].Text;
                cmbGorivo.Text = item.SubItems[6].Text;

                

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            button2.Visible = true;
            button2.Enabled = true;
            button1.Enabled = false;
            txtSifra.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button2.Visible = false;
            button1.Enabled = true;
            txtSifra.Enabled = true;
        }

        private void toolStripLabel4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            IzmeniProizvod();
            PuniListBoxView();
        }

        private void IzmeniProizvod()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("AzurirajPodatkeVozilo", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@VoziloID", SqlDbType.VarChar).Value = txtSifra.Text.ToString();
            cmd.Parameters.AddWithValue("@Registracija", SqlDbType.VarChar).Value = txtRegistracija.Text.ToString();
            cmd.Parameters.AddWithValue("@GodinaProizvodnje", SqlDbType.VarChar).Value = txtGodinaP.Text.ToString();
            cmd.Parameters.AddWithValue("@Kilometraza", SqlDbType.VarChar).Value = txtPredjenaKM.Text.ToString();
            cmd.Parameters.AddWithValue("@ModelNaziv", SqlDbType.VarChar).Value = cmbModel.Text.ToString();
            cmd.Parameters.AddWithValue("@BojaNaziv", SqlDbType.VarChar).Value = cmbBoja.Text.ToString();
            //cmd.Parameters.AddWithValue("@DatumPrijema", SqlDbType.DateTime).Value = Convert.ToDateTime(dtpDatumPrijema.Value.ToString());
            //cmd.Parameters.AddWithValue("@RokTrajanja", SqlDbType.DateTime).Value = Convert.ToDateTime(maskedRokTrajanja.Text.ToString());

           
            cmd.Parameters.AddWithValue("@GorivoNaziv", SqlDbType.DateTime).Value = cmbGorivo.Text.ToString();

            cmd.Parameters.AddWithValue("@Cena", SqlDbType.VarChar).Value = txtCena.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();

        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            Form2 forma = new Form2();
            forma.ShowDialog();
        }
    }
}

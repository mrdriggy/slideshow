﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProduzeniBoravak
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-TOF6O3H\SQLEXPRESS;Initial Catalog=4EIT_A5_ProduzeniBoravak;Integrated Security=True"); /* MM 2 sp*/
        //SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-20OQNSD\SQLEXPRESS;Initial Catalog=DemoMatura;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;


        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void PuniListView()
        {
            listView1.Items.Clear();

            kom.Connection = Kon;
            kom.CommandText = "EXEC PuniListView";
            Kon.Open();
            dr = kom.ExecuteReader();

            while (dr.Read())
            {

                ListViewItem red = new ListViewItem(dr[0].ToString());
                for (int i = 1; i < 5; i++) /* i IDE DO KOLIKO POLJA VRACA PROCEDURA*/
                    red.SubItems.Add(dr[i].ToString());
                listView1.Items.Add(red);
            }
            Kon.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListView();
            UnesiAktivnost();
        }

        private void SaListViewNaKontrole()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                id = Convert.ToInt32(item.SubItems[0].Text);

                txtSifra.Text = id.ToString();
                txtNaziv.Text = item.SubItems[1].Text;
                cmbDan.Text = item.SubItems[2].Text;
                txtPocetak.Text = item.SubItems[3].Text;
                txtZavrsetak.Text = item.SubItems[4].Text;
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }
        private void UnesiAktivnost()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("UnesiAktivnost", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@NazivAktivnosti", SqlDbType.VarChar).Value = txtNaziv.Text.ToString();
            cmd.Parameters.AddWithValue("@Dan", SqlDbType.VarChar).Value = cmbDan.Text.ToString();
            cmd.Parameters.AddWithValue("@Pocetak", SqlDbType.VarChar).Value = txtPocetak.Text.ToString();
            cmd.Parameters.AddWithValue("@Zavrsetak", SqlDbType.VarChar).Value = txtZavrsetak.Text.ToString();
            
            
            cmd.ExecuteNonQuery();


            Kon.Close();

        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            UnesiAktivnost();
            PuniListView();
            txtSifra.Enabled = false;

        }
    }
}

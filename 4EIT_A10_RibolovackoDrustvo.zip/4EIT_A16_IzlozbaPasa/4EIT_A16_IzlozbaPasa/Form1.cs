﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A16_IzlozbaPasa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=LAPTOP-U3UPVFJG\MSSQLSERVER01;Initial Catalog=4EIT_A16_IzlozbaPasa;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PuniComboPas();
            PuniComboIzlozba();
            PuniComboKategorija();
            PuniComboIzlozba2();

        }

        private void PuniComboPas()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboPas", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboPas.DataSource = dt;
            comboPas.DisplayMember = "Pas";

            Kon.Close();
        }

        private void PuniComboIzlozba()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboIzlozba", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboIzlozba.DataSource = dt;
            comboIzlozba.DisplayMember = "Izlozba";

            Kon.Close();
        }

        private void PuniComboKategorija()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboKategorija", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboKategorija.DataSource = dt;
            comboKategorija.DisplayMember = "Kategorija";

            Kon.Close();
        }

        private void UnesiPsa()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("UnesiPsa", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            string Izlozba = comboIzlozba.Text.ToString();
            string[] OdabranaIzlozba = Izlozba.Split('-');

            string Pas = comboPas.Text.ToString();
            string OdabranPas = Pas.Substring(0, 1).Trim();

            string Kategorija = comboKategorija.Text.ToString();
            string OdabranaKategorija = Kategorija.Substring(0, 1).Trim();


            cmd.Parameters.AddWithValue("@Izlozba", SqlDbType.VarChar).Value = OdabranaIzlozba[0].ToString();
            cmd.Parameters.AddWithValue("@Pas", SqlDbType.VarChar).Value = OdabranPas;
            cmd.Parameters.AddWithValue("@Kategorija", SqlDbType.VarChar).Value = OdabranaKategorija.ToString();
            cmd.ExecuteNonQuery();

            Kon.Close();

            MessageBox.Show("Uspesno ste se prijavili", "Prijava uspesna", MessageBoxButtons.OK);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            UnesiPsa();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
        }

        private void PuniComboIzlozba2()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboIzlozba", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "Izlozba";

            Kon.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PuniGridChart();
        }
        private void PuniGridChart()
        {
            Kon.Open();

            string Izlozba2 = comboBox1.Text.ToString();
            string[] OdabranaIzlozba2 = Izlozba2.Split('-');

            SqlCommand cmd = new SqlCommand("PuniGridIChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@IzlozbaID", SqlDbType.VarChar).Value = OdabranaIzlozba2[0].ToString();

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            dataGridView1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Naziv";
            chart1.Series["Series1"].YValueMembers = "BrojPasa";
            chart1.Titles.Add("PRIMER CHART");

            Kon.Close();
        }
    }
}

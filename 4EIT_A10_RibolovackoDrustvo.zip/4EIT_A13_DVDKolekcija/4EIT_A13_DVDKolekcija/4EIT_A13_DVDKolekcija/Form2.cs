﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A13_DVDKolekcija
{
    public partial class Form2 : Form
    {
        SqlConnection Kon = new SqlConnection("Data Source=DESKTOP-TOF6O3H\\SQLEXPRESS;Initial Catalog=4EIT_A13_DVDKolekcija;Integrated Security=True");
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            PuniDataGrid();
        }

        private void PuniDataGrid()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("Prikaz_broja_filmova", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            dataGridView1.DataSource = dt;

            Kon.Close();
        }

        private void PuniChart()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("Prikaz_broja_filmova", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            chart1.Series["Broj filmova"].XValueMember = "Ime";
            chart1.Series["Broj filmova"].YValueMembers = "Broj filmova";
            chart1.Titles.Add("Broj filmova po producentu");

            Kon.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PuniChart();
        }
    }
}

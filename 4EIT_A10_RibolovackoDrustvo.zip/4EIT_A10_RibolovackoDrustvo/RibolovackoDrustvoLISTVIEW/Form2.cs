﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RibolovackoDrustvoLISTVIEW
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-TOF6O3H\SQLEXPRESS;Initial Catalog=4EIT_A10_RibolovackoDrustvo;Integrated Security=True"); /* MM 2 sp*/
        //SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-20OQNSD\SQLEXPRESS;Initial Catalog=DemoMatura;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void Form2_Load(object sender, EventArgs e)
        {
            PuniComboPecaros();
        }

        private void PuniComboPecaros()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboPecaros", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbPecaros.DataSource = dt;
            cmbPecaros.DisplayMember = "Pecaros";


            Kon.Close();
        }

        private void PuniGridiChart()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridiChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            string Pecaros = cmbPecaros.Text.ToString();
            string PecarosID = Pecaros.Substring(0, 1).Trim();


            cmd.Parameters.AddWithValue("@PecarosID", SqlDbType.VarChar).Value = PecarosID;
            cmd.Parameters.AddWithValue("@DatumOD", SqlDbType.VarChar).Value = dateTimePicker1.Value;
            cmd.Parameters.AddWithValue("@DatumDO", SqlDbType.VarChar).Value = dateTimePicker2.Value;

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            dataGridView1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Naziv";
            chart1.Series["Series1"].YValueMembers = "Broj";
            chart1.Titles.Add("PRIMER CHART");

            Kon.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PuniGridiChart();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _4EIT_A13_DVDKolekcija
{
    public partial class Form1 : Form
    {
        SqlConnection Kon = new SqlConnection("Data Source=DESKTOP-TOF6O3H\\SQLEXPRESS;Initial Catalog=4EIT_A13_DVDKolekcija;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            PuniListBox();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 analiza = new Form2();
            analiza.ShowDialog();
        }

        private void PuniListBox()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("Prikaz_Producenta", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Producent";

            Kon.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Izmena();
            PuniListBox();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListBoxUKontrole();
        }

        private void Izmena()
        {
            Kon.Open();
            try
            {
                SqlCommand cmd = new SqlCommand("Izmena", Kon);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ID", SqlDbType.Int).Value = Convert.ToInt32(textBox1.Text);
                cmd.Parameters.AddWithValue("@Ime", SqlDbType.NVarChar).Value = textBox2.Text.ToString();
                cmd.Parameters.AddWithValue("@Email", SqlDbType.NVarChar).Value = textBox3.Text.ToString();

                cmd.ExecuteNonQuery();

                MessageBox.Show("Uspesno ste izmenili podatke", "Uspesna izmena", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Desila se greska tokom izvrsavanja zahteva", "Greska", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Kon.Close();
        }

        private void ListBoxUKontrole()
        {
            try
            {
                string Par_Proizvod = listBox1.Text.ToString();
                string[] PProizvod = Par_Proizvod.Split('-');

                textBox1.Text = PProizvod[0].ToString().Trim();
                textBox2.Text = PProizvod[1].ToString().Trim();
                textBox3.Text = PProizvod[2].ToString().Trim();
            }
            catch(System.IndexOutOfRangeException)
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Zamislite da je ovo forma na kojoj su napisane informacije o ovoj aplikaciji - Denis Đuriš IV-eit", "O aplikaciji", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

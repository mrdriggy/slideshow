﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DemoMatura
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-TOF6O3H\SQLEXPRESS;Initial Catalog=DemoMatura;Integrated Security=True"); /* MM 2 sp*/
//        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-20OQNSD\SQLEXPRESS;Initial Catalog=DemoMatura;Integrated Security=True"); /* MM 2 sp*/
        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;
        private void PuniCheckListBox()
        {
            int i;
         
            Kon.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Kategorija WHERE Kategorija <> '-' ORDER BY Kategorija", Kon);
            cmd.CommandType = CommandType.Text;

            SqlDataAdapter sda = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();

            sda.Fill(dt);

            for (i = 0; i < dt.Rows.Count; i++)
            {
                checkedListBox1.Items.Add(dt.Rows[i]["Kategorija"].ToString());
            }

            Kon.Close();
        }

        private void PuniGridChart()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Param1", SqlDbType.VarChar).Value = checkedListBox1.CheckedItems[0].ToString();
            cmd.Parameters.AddWithValue("@Param2", SqlDbType.VarChar).Value = checkedListBox1.CheckedItems[1].ToString();
            cmd.Parameters.AddWithValue("@Param3", SqlDbType.VarChar).Value = checkedListBox1.CheckedItems[2].ToString();

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            dataGridView1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Kategorija";
            chart1.Series["Series1"].YValueMembers = "Vrednost";
            chart1.Titles.Add("PRIMER CHART");

            Kon.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            PuniCheckListBox();
        }

        private void btnPrikazi_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.CheckedItems.Count != 3)
            {
                MessageBox.Show("GRESKA! MOARATE IZABRATI TRI PROIZVODA IZ CHECKLISTBOX-a!");
            }
            else
            {
                if (checkedListBox1.CheckedItems.Count != 0)
                {
                    chart1.Titles.Clear();

                    PuniGridChart();
                }
            }
            
        }
    }
}

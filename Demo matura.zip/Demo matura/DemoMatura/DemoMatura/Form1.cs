﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DemoMatura
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-TOF6O3H\SQLEXPRESS;Initial Catalog=DemoMatura;Integrated Security=True"); /* MM 2 sp*/
        //        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-20OQNSD\SQLEXPRESS;Initial Catalog=DemoMatura;Integrated Security=True"); /* MM 2 sp*/
       
                SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;
        private void UnesiProizvod()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("UnesiProizvod", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@NazivProizvoda", SqlDbType.VarChar).Value = txtNazivP.Text.ToString();
            cmd.Parameters.AddWithValue("@JedinicaMere", SqlDbType.VarChar).Value = cmbJM.Text.ToString();
            cmd.Parameters.AddWithValue("@Kategorija", SqlDbType.VarChar).Value = cmbKategorija.Text.ToString();
            cmd.Parameters.AddWithValue("@Cena", SqlDbType.VarChar).Value = txtCena.Text.ToString();
            cmd.Parameters.AddWithValue("@Kolicina", SqlDbType.VarChar).Value = txtKolicina.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumPrijema", SqlDbType.VarChar).Value = dtpDatumPrijema.Value.ToString();
            cmd.Parameters.AddWithValue("@RokTrajanja", SqlDbType.VarChar).Value = maskedRokTrajanja.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();

        }
        private void UnesiProizvodLB()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("UnesiProizvod", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@NazivProizvoda", SqlDbType.VarChar).Value = txtNazivProizvodaLB.Text.ToString();
            cmd.Parameters.AddWithValue("@JedinicaMere", SqlDbType.VarChar).Value = cmbJMLB.Text.ToString();
            cmd.Parameters.AddWithValue("@Kategorija", SqlDbType.VarChar).Value = cmbKategorijaLB.Text.ToString();
            cmd.Parameters.AddWithValue("@Cena", SqlDbType.VarChar).Value = txtCenaLB.Text.ToString();
            cmd.Parameters.AddWithValue("@Kolicina", SqlDbType.VarChar).Value = txtKolicinaLB.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumPrijema", SqlDbType.VarChar).Value = dtpDatumPrijemaLB.Value.ToString();
            cmd.Parameters.AddWithValue("@RokTrajanja", SqlDbType.VarChar).Value = maskedRokTrajanjaLB.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();
        }

        private void PuniListView()
        {
            listView1.Items.Clear();

            kom.Connection = Kon;
            kom.CommandText = "EXEC PuniListView";
            Kon.Open();
            dr = kom.ExecuteReader();

            while (dr.Read())
            {

                ListViewItem red = new ListViewItem(dr[0].ToString());
                for (int i = 1; i < 9; i++) /* i IDE DO KOLIKO POLJA VRACA PROCEDURA*/
                    red.SubItems.Add(dr[i].ToString());
                listView1.Items.Add(red);
            }
            Kon.Close();
        }
        private void BrisiProizvod()
        {
            string poruka = "Zelite da obrisete stavku?";
            string naslov = "Brisanje proizvoda";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(poruka, naslov, buttons);

            if (result == DialogResult.Yes)
            {
                Kon.Open();
                SqlCommand cmd = new SqlCommand("BrisiProizvod", Kon);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@SifraProizvoda", SqlDbType.VarChar).Value = txtSifraP.Text.ToString();

                cmd.ExecuteNonQuery();

                Kon.Close();
            }


        }
        private void BrisiProizvodLB()
        {
            string poruka = "Zelite da obrisete stavku?";
            string naslov = "Brisanje proizvoda";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(poruka, naslov, buttons);

            if (result == DialogResult.Yes)
            {
                Kon.Open();
                SqlCommand cmd = new SqlCommand("BrisiProizvod", Kon);
                cmd.CommandType = CommandType.StoredProcedure;
                
                cmd.Parameters.AddWithValue("@SifraProizvoda", SqlDbType.VarChar).Value = txtSifraProizvodaLB.Text.ToString();

                cmd.ExecuteNonQuery();

                Kon.Close();
            }

        }
        private void IzmeniProizvod()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("IzmeniProizvod", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@SifraProizvoda", SqlDbType.VarChar).Value = txtSifraP.Text.ToString();
            cmd.Parameters.AddWithValue("@NazivProizvoda", SqlDbType.VarChar).Value = txtNazivP.Text.ToString();
            cmd.Parameters.AddWithValue("@JedinicaMere", SqlDbType.VarChar).Value = cmbJM.Text.ToString();
            cmd.Parameters.AddWithValue("@Kategorija", SqlDbType.VarChar).Value = cmbKategorija.Text.ToString();
            cmd.Parameters.AddWithValue("@Cena", SqlDbType.VarChar).Value = txtCena.Text.ToString();
            cmd.Parameters.AddWithValue("@Kolicina", SqlDbType.VarChar).Value = txtKolicina.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumPrijema", SqlDbType.VarChar).Value = dtpDatumPrijema.Value.ToString();
            cmd.Parameters.AddWithValue("@RokTrajanja", SqlDbType.VarChar).Value = maskedRokTrajanja.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();

        }

        private void IzmeniProizvodLB()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("IzmeniProizvod", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@SifraProizvoda", SqlDbType.VarChar).Value = txtSifraProizvodaLB.Text.ToString();
            cmd.Parameters.AddWithValue("@NazivProizvoda", SqlDbType.VarChar).Value = txtNazivProizvodaLB.Text.ToString();
            cmd.Parameters.AddWithValue("@JedinicaMere", SqlDbType.VarChar).Value = cmbJMLB.Text.ToString();
            cmd.Parameters.AddWithValue("@Kategorija", SqlDbType.VarChar).Value = cmbKategorijaLB.Text.ToString();
            cmd.Parameters.AddWithValue("@Cena", SqlDbType.VarChar).Value = txtCenaLB.Text.ToString();
            cmd.Parameters.AddWithValue("@Kolicina", SqlDbType.VarChar).Value = txtKolicinaLB.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumPrijema", SqlDbType.VarChar).Value = dtpDatumPrijemaLB.Value.ToString();
            cmd.Parameters.AddWithValue("@RokTrajanja", SqlDbType.VarChar).Value = maskedRokTrajanjaLB.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();
        }
        private void SaListViewNaKontrole()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                id = Convert.ToInt32(item.SubItems[0].Text);

                txtSifraP.Text = id.ToString();
                txtNazivP.Text = item.SubItems[1].Text;
                cmbJM.Text = item.SubItems[2].Text;
                cmbKategorija.Text = item.SubItems[3].Text;
                txtCena.Text =item.SubItems[4].Text;
                txtKolicina.Text = item.SubItems[5].Text;
                txtVrednost.Text = item.SubItems[6].Text;
                dtpDatumPrijema.Value = Convert.ToDateTime(item.SubItems[7].Text);
                //if (item.SubItems[7].Text == "") 
                //{
                //    dtpDatumPrijema.Value = DateTime.Now;
                //}
                //else
                //{
                //    dtpDatumPrijema.Value = Convert.ToDateTime(item.SubItems[7].Text);
                //}
                maskedRokTrajanja.Text = item.SubItems[8].Text;

            }

        }
        private void PuniComboKategorija()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("SELECT * FROM Kategorija ORDER BY Kategorija", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbKategorija.DataSource = dt;
            cmbKategorija.DisplayMember = "Kategorija";

            cmbKategorijaLB.DataSource = dt;
            cmbKategorijaLB.DisplayMember = "Kategorija";

            Kon.Close();
        }

        private void PuniListBox()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniListBox", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Nesto";

            Kon.Close();

        }

        private void BrisanjeKontrola()
        {
            txtSifraP.Clear();
            txtNazivP.Clear();
            cmbJM.Text = "";
            cmbKategorija.Text = "";
            txtCena.Clear();
            txtKolicina.Clear();
            txtVrednost.Clear();
            dtpDatumPrijema.Value = DateTime.Now;
            maskedRokTrajanja.Text = DateTime.Now.ToString("yyyy.MM.dd");
        }

        private void BrisanjeKontrolaLB()
        {
            txtSifraProizvodaLB.Clear();
            txtNazivProizvodaLB.Clear();
            cmbJMLB.Text = "";
            cmbKategorijaLB.Text = "";
            txtCenaLB.Clear();
            txtKolicinaLB.Clear();
            txtVrednostLB.Clear();
            dtpDatumPrijemaLB.Value = DateTime.Now;
            maskedRokTrajanjaLB.Text= DateTime.Now.ToString("yyyy.MM.dd");
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtSifraP.Enabled = false;
            txtVrednost.Enabled = false;
            txtSifraProizvodaLB.Enabled = false;
            txtVrednostLB.Enabled = false;

            txtVrednost.BackColor = Color.Yellow;
            txtVrednost.ForeColor = Color.Black;
            
            PuniListView();
            PuniComboKategorija();
            PuniListBox();

            dtpDatumPrijema.Value = DateTime.Now;
            maskedRokTrajanja.Text = DateTime.Now.ToString("yyyy.MM.dd");

            dtpDatumPrijemaLB.Value = DateTime.Now;
            maskedRokTrajanjaLB.Text = DateTime.Now.ToString("yyyy.MM.dd");

        }

        private void btnUnos_Click(object sender, EventArgs e)
        {
            if (txtSifraP.Text == "")
            {
                UnesiProizvod();
                PuniListView();
                PuniListBox();
                BrisanjeKontrola();
            }
            else 
            {
                MessageBox.Show("GRESKA! PROIZVOD POD OVOM SIFROM VEC POSTOJI!!!");
                BrisanjeKontrola();
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();

        }

        private void btnBrisanje_Click(object sender, EventArgs e)
        {
            BrisiProizvod();
            PuniListView();
            PuniListBox();
            BrisanjeKontrola();
        }

        private void btnIzmena_Click(object sender, EventArgs e)
        {
            IzmeniProizvod();
            PuniListView();
            PuniListBox();
            BrisanjeKontrola();
        }

        private void aNALIZASTANJAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void btnPrazniKontrole_Click(object sender, EventArgs e)
        {
            BrisanjeKontrola();
        }

        private void btnIzlazLB_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrazniKontroleLB_Click(object sender, EventArgs e)
        {
            BrisanjeKontrolaLB();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            string Par_Proizvod = listBox1.Text.ToString();
            string[] PProizvod = Par_Proizvod.Split('-');

            txtSifraProizvodaLB.Text = PProizvod[0].ToString().Trim();
            txtNazivProizvodaLB.Text = PProizvod[1].ToString().Trim();
            cmbJMLB.Text = PProizvod[2].ToString().Trim();
            cmbKategorijaLB.Text = PProizvod[3].ToString().Trim();
            txtCenaLB.Text = PProizvod[4].ToString().Trim();
            txtKolicinaLB.Text = PProizvod[5].ToString().Trim();
            txtVrednostLB.Text = PProizvod[6].ToString().Trim();
            dtpDatumPrijemaLB.Value = Convert.ToDateTime(PProizvod[7].ToString().Trim());
            maskedRokTrajanjaLB.Text = PProizvod[8].ToString().Trim();

            //comboProizvodjac.Text = PModel[2].ToString().Trim();
            //textNazivModel.Text = PModel[2].ToString().Trim() + "  " + PModel[1].ToString().Trim();
        }

        private void btnUnosLB_Click(object sender, EventArgs e)
        {
            UnesiProizvodLB();
            PuniListBox();
            PuniListView();
        }

        private void btnIzmenaLB_Click(object sender, EventArgs e)
        {
            IzmeniProizvodLB();
            PuniListBox();
            PuniListView();
            BrisanjeKontrolaLB();
        }

        private void btnBrisanjeLB_Click(object sender, EventArgs e)
        {
            BrisiProizvodLB();
            PuniListBox();
            PuniListView();
            BrisanjeKontrolaLB();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PolovniAutomobili
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-TOF6O3H\SQLEXPRESS;Initial Catalog=4EIT_А6_PolovniAutomobili;Integrated Security=True"); /* MM 2 sp*/
        //SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-20OQNSD\SQLEXPRESS;Initial Catalog=DemoMatura;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;


        private void Form1_Load(object sender, EventArgs e)
        {
            PuniListView();
            PuniComboModel();
            PuniComboProizvodjac();
        }

        private void PuniListView()
        {
            listView1.Items.Clear();

            kom.Connection = Kon;
            kom.CommandText = "EXEC PuniListView";
            Kon.Open();
            dr = kom.ExecuteReader();

            while (dr.Read())
            {

                ListViewItem red = new ListViewItem(dr[0].ToString());
                for (int i = 1; i < 3; i++) /* i IDE DO KOLIKO POLJA VRACA PROCEDURA*/
                    red.SubItems.Add(dr[i].ToString());
                listView1.Items.Add(red);
            }
            Kon.Close();

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaListViewNaKontrole();
        }

        private void SaListViewNaKontrole()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {


                txtSifra.Text = item.SubItems[0].Text;
                cmbNaziv.Text = item.SubItems[1].Text;
                cmbProizvodjac.Text = item.SubItems[2].Text;


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IzmeniUpdate();
            PuniListView();
        }

        private void IzmeniUpdate()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("IzmeniUpdate", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            int VoziloID = Convert.ToInt32(txtSifra.Text);
            int ModelID = Convert.ToInt32(cmbNaziv.Text.Substring(0, 1));

            cmd.Parameters.AddWithValue("@ModelID", SqlDbType.VarChar).Value = ModelID;
            cmd.Parameters.AddWithValue("@VoziloID", SqlDbType.VarChar).Value = VoziloID;
            
            

            cmd.ExecuteNonQuery();

            Kon.Close();

        }

        private void PuniComboProizvodjac()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboProizvodjac", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbProizvodjac.DataSource = dt;
            cmbProizvodjac.DisplayMember = "Proizvodjac";

            

            Kon.Close();
        }

        private void PuniComboModel()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniComboModel", Kon);
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            cmbNaziv.DataSource = dt;
            cmbNaziv.DisplayMember = "Model";


            Kon.Close();
        }

        private void PuniGridChart()
        {
            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniGridChart", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@GodinaProizvodnjeMin", SqlDbType.VarChar).Value = numericUpDown1.Value ;
            cmd.Parameters.AddWithValue("@GodinaProizvodnjeMax", SqlDbType.VarChar).Value = numericUpDown2.Value;
            cmd.Parameters.AddWithValue("@Kilometraza", SqlDbType.VarChar).Value = textBox5.Text.ToString();

            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());

            chart1.DataSource = dt;
            dataGridView1.DataSource = dt;

            chart1.Series["Series1"].XValueMember = "Proizvodjac";
            chart1.Series["Series1"].YValueMembers = "BrVozila";
            chart1.Titles.Add("PRIMER CHART");

            Kon.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PuniGridChart();
        }
    }
}
